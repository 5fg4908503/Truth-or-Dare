import TruthOrDareGame from '@/components/game/TruthOrDareGame'

export default function Home() {
  return <TruthOrDareGame />
}