import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    // Test database connection
    await db.$connect()
    
    // Test creating a simple room
    const roomCount = await db.room.count()
    
    await db.$disconnect()
    
    return NextResponse.json({ 
      success: true, 
      message: 'Database connection successful',
      roomCount 
    })
  } catch (error) {
    console.error('Database connection error:', error)
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }, { status: 500 })
  }
}