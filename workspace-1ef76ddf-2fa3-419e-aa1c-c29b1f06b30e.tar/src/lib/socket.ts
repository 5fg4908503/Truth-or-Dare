import { Server } from 'socket.io';
import { db } from './db';

interface Room {
  id: string;
  roomId: string;
  hostId: string;
  status: 'waiting' | 'playing' | 'finished';
  direction: 'clockwise' | 'anticlockwise';
  currentTurn: number;
  players: Player[];
  questions: Question[];
  messages: Message[];
}

interface Player {
  id: string;
  socketId: string;
  name: string;
  roomId: string;
  isHost: boolean;
  isReady: boolean;
}

interface Question {
  id: string;
  roomId: string;
  type: 'truth' | 'dare';
  content: string;
  playerId: string;
}

interface Message {
  id: string;
  roomId: string;
  playerId: string;
  content: string;
  type: 'text' | 'emoji';
}

// In-memory room storage (for simplicity)
const rooms = new Map<string, Room>();

// Load existing rooms from database on startup
const loadRoomsFromDatabase = async () => {
  try {
    const dbRooms = await db.room.findMany({
      include: {
        players: true,
        questions: true,
        messages: true,
      },
    });

    for (const dbRoom of dbRooms) {
      const roomData: Room = {
        id: dbRoom.id,
        roomId: dbRoom.roomId,
        hostId: dbRoom.hostId,
        status: dbRoom.status as 'waiting' | 'playing' | 'finished',
        direction: dbRoom.direction as 'clockwise' | 'anticlockwise',
        currentTurn: dbRoom.currentTurn,
        players: dbRoom.players,
        questions: dbRoom.questions,
        messages: dbRoom.messages,
      };
      rooms.set(dbRoom.roomId, roomData);
    }
    console.log(`Loaded ${rooms.size} rooms from database`);
  } catch (error) {
    console.error('Failed to load rooms from database:', error);
  }
};

export const setupSocket = (io: Server) => {
  // Load rooms from database on startup
  loadRoomsFromDatabase();

  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);

    // Create room
    socket.on('createRoom', async (data: { playerName: string; roomId: string }) => {
      try {
        const { playerName, roomId } = data;
        
        // Create room in database
        const room = await db.room.create({
          data: {
            roomId,
            hostId: socket.id,
            status: 'waiting',
            direction: 'clockwise',
            currentTurn: 0,
          },
        });

        // Create player in database
        const player = await db.player.create({
          data: {
            socketId: socket.id,
            name: playerName,
            roomId: room.id,
            isHost: true,
            isReady: false,
          },
        });

        // Store in memory
        const roomData: Room = {
          id: room.id,
          roomId: room.roomId,
          hostId: room.hostId,
          status: room.status as 'waiting' | 'playing' | 'finished',
          direction: room.direction as 'clockwise' | 'anticlockwise',
          currentTurn: room.currentTurn,
          players: [player],
          questions: [],
          messages: [],
        };
        rooms.set(roomId, roomData);

        socket.join(roomId);
        socket.emit('roomCreated', { roomId, player });
      } catch (error) {
        socket.emit('error', { message: 'Failed to create room' });
      }
    });

    // Join room
    socket.on('joinRoom', async (data: { playerName: string; roomId: string }) => {
      try {
        const { playerName, roomId } = data;
        
        let roomData = rooms.get(roomId);
        
        if (!roomData) {
          // Try to load room from database
          const dbRoom = await db.room.findUnique({
            where: { roomId },
            include: {
              players: true,
              questions: true,
              messages: true,
            },
          });
          
          if (dbRoom) {
            roomData = {
              id: dbRoom.id,
              roomId: dbRoom.roomId,
              hostId: dbRoom.hostId,
              status: dbRoom.status as 'waiting' | 'playing' | 'finished',
              direction: dbRoom.direction as 'clockwise' | 'anticlockwise',
              currentTurn: dbRoom.currentTurn,
              players: dbRoom.players,
              questions: dbRoom.questions,
              messages: dbRoom.messages,
            };
            rooms.set(roomId, roomData);
          }
        }
        
        if (!roomData) {
          socket.emit('error', { message: 'Room not found' });
          return;
        }

        // Create player in database
        const player = await db.player.create({
          data: {
            socketId: socket.id,
            name: playerName,
            roomId: roomData.id,
            isHost: false,
            isReady: false,
          },
        });

        roomData.players.push(player);
        socket.join(roomId);

        socket.emit('roomJoined', { 
          roomId, 
          player,
          room: {
            id: roomData.id,
            roomId: roomData.roomId,
            status: roomData.status,
            direction: roomData.direction,
            currentTurn: roomData.currentTurn,
            players: roomData.players,
            questions: roomData.questions,
            messages: roomData.messages.map(msg => ({
              id: msg.id,
              playerName: roomData.players.find(p => p.id === msg.playerId)?.name || 'Unknown',
              content: msg.content,
              type: msg.type,
            })),
          }
        });
        io.to(roomId).emit('playerJoined', { player, players: roomData.players });
      } catch (error) {
        socket.emit('error', { message: 'Failed to join room' });
      }
    });

    // Add question
    socket.on('addQuestion', async (data: { type: 'truth' | 'dare'; content: string }) => {
      try {
        const { type, content } = data;
        const roomData = Array.from(rooms.values()).find(r => 
          r.players.some(p => p.socketId === socket.id)
        );

        if (!roomData) {
          socket.emit('error', { message: 'Room not found' });
          return;
        }

        const player = roomData.players.find(p => p.socketId === socket.id);
        if (!player) return;

        // Create question in database
        const question = await db.question.create({
          data: {
            roomId: roomData.id,
            type,
            content,
            playerId: player.id,
          },
        });

        roomData.questions.push(question);
        io.to(roomData.roomId).emit('questionAdded', { question, questions: roomData.questions });
      } catch (error) {
        socket.emit('error', { message: 'Failed to add question' });
      }
    });

    // Player ready
    socket.on('playerReady', async () => {
      try {
        const roomData = Array.from(rooms.values()).find(r => 
          r.players.some(p => p.socketId === socket.id)
        );

        if (!roomData) return;

        const player = roomData.players.find(p => p.socketId === socket.id);
        if (!player) return;

        player.isReady = true;
        
        // Update in database
        await db.player.update({
          where: { id: player.id },
          data: { isReady: true },
        });

        io.to(roomData.roomId).emit('playerReady', { player, players: roomData.players });
      } catch (error) {
        socket.emit('error', { message: 'Failed to set ready' });
      }
    });

    // Start game
    socket.on('startGame', async () => {
      try {
        const roomData = Array.from(rooms.values()).find(r => 
          r.players.some(p => p.socketId === socket.id)
        );

        if (!roomData) return;

        const player = roomData.players.find(p => p.socketId === socket.id);
        if (!player || !player.isHost) return;

        roomData.status = 'playing';
        
        // Update in database
        await db.room.update({
          where: { id: roomData.id },
          data: { status: 'playing' },
        });

        io.to(roomData.roomId).emit('gameStarted', { room: roomData });
      } catch (error) {
        socket.emit('error', { message: 'Failed to start game' });
      }
    });

    // Spin bottle
    socket.on('spinBottle', () => {
      const roomData = Array.from(rooms.values()).find(r => 
        r.players.some(p => p.socketId === socket.id)
      );

      if (!roomData || roomData.status !== 'playing') return;

      const randomIndex = Math.floor(Math.random() * roomData.players.length);
      const selectedPlayer = roomData.players[randomIndex];
      
      // Toggle direction
      roomData.direction = roomData.direction === 'clockwise' ? 'anticlockwise' : 'clockwise';
      roomData.currentTurn++;

      io.to(roomData.roomId).emit('bottleSpun', { 
        selectedPlayer, 
        direction: roomData.direction,
        currentTurn: roomData.currentTurn
      });
    });

    // Choose truth or dare
    socket.on('chooseTruth', () => {
      handleQuestionChoice(socket, 'truth');
    });

    socket.on('chooseDare', () => {
      handleQuestionChoice(socket, 'dare');
    });

    // Send message
    socket.on('sendMessage', async (data: { content: string }) => {
      try {
        const { content } = data;
        const roomData = Array.from(rooms.values()).find(r => 
          r.players.some(p => p.socketId === socket.id)
        );

        if (!roomData) return;

        const player = roomData.players.find(p => p.socketId === socket.id);
        if (!player) return;

        // Create message in database
        const message = await db.message.create({
          data: {
            roomId: roomData.id,
            playerId: player.id,
            content,
            type: content.length <= 2 ? 'emoji' : 'text',
          },
        });

        const messageData = {
          id: message.id,
          playerName: player.name,
          content: message.content,
          type: message.type,
        };

        roomData.messages.push({
          id: message.id,
          roomId: message.roomId,
          playerId: message.playerId,
          content: message.content,
          type: message.type,
        });
        io.to(roomData.roomId).emit('newMessage', messageData);
      } catch (error) {
        socket.emit('error', { message: 'Failed to send message' });
      }
    });

    // Close room
    socket.on('closeRoom', async () => {
      try {
        const roomData = Array.from(rooms.values()).find(r => 
          r.players.some(p => p.socketId === socket.id)
        );

        if (!roomData) {
          socket.emit('error', { message: 'Room not found' });
          return;
        }

        const player = roomData.players.find(p => p.socketId === socket.id);
        if (!player || !player.isHost) {
          socket.emit('error', { message: 'Only host can close the room' });
          return;
        }

        // Notify all players in the room
        io.to(roomData.roomId).emit('roomClosed');

        // Remove all players from the room
        for (const roomPlayer of roomData.players) {
          const playerSocket = io.sockets.sockets.get(roomPlayer.socketId);
          if (playerSocket) {
            playerSocket.leave(roomData.roomId);
          }
        }

        // Delete room from database
        await db.room.delete({
          where: { id: roomData.id },
        });

        // Remove room from memory
        rooms.delete(roomData.roomId);

        console.log('Room closed by host:', roomData.roomId);
      } catch (error) {
        socket.emit('error', { message: 'Failed to close room' });
      }
    });

    // Handle disconnect
    socket.on('disconnect', async () => {
      console.log('Client disconnected:', socket.id);
      
      // Find and remove player from room
      for (const [roomId, roomData] of rooms.entries()) {
        const playerIndex = roomData.players.findIndex(p => p.socketId === socket.id);
        if (playerIndex !== -1) {
          const player = roomData.players[playerIndex];
          roomData.players.splice(playerIndex, 1);
          
          // Update database
          await db.player.delete({
            where: { id: player.id },
          });

          io.to(roomId).emit('playerLeft', { player, players: roomData.players });

          // Remove room if empty and not in playing state
          if (roomData.players.length === 0 && roomData.status !== 'playing') {
            rooms.delete(roomId);
            await db.room.delete({
              where: { id: roomData.id },
            });
            console.log('Room deleted (empty):', roomId);
          }
          break;
        }
      }
    });
  });
};

function handleQuestionChoice(socket: any, type: 'truth' | 'dare') {
  const roomData = Array.from(rooms.values()).find(r => 
    r.players.some(p => p.socketId === socket.id)
  );

  if (!roomData) return;

  const availableQuestions = roomData.questions.filter(q => q.type === type);
  if (availableQuestions.length === 0) return;

  const randomQuestion = availableQuestions[Math.floor(Math.random() * availableQuestions.length)];
  
  io.to(roomData.roomId).emit('questionSelected', { question: randomQuestion });
}