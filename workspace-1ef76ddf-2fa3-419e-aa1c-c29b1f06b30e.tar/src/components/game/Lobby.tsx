'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Users, Play, Sparkles } from 'lucide-react'

interface LobbyProps {
  onCreateRoom: (playerName: string, roomId: string) => void
  onJoinRoom: (playerName: string, roomId: string) => void
  connectionStatus?: 'connecting' | 'connected' | 'disconnected'
}

export default function Lobby({ onCreateRoom, onJoinRoom, connectionStatus = 'connecting' }: LobbyProps) {
  const [createPlayerName, setCreatePlayerName] = useState('')
  const [joinPlayerName, setJoinPlayerName] = useState('')
  const [roomId, setRoomId] = useState('')
  const [createRoomId, setCreateRoomId] = useState('')

  const generateRoomId = () => {
    const id = Math.random().toString(36).substring(2, 8).toUpperCase()
    setCreateRoomId(id)
  }

  const handleCreateRoom = () => {
    if (createPlayerName.trim() && createRoomId.trim()) {
      onCreateRoom(createPlayerName.trim(), createRoomId.trim())
    }
  }

  const handleJoinRoom = () => {
    if (joinPlayerName.trim() && roomId.trim()) {
      onJoinRoom(joinPlayerName.trim(), roomId.trim())
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-blue-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-pink-400 to-purple-600 rounded-full mb-4">
            <Sparkles className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent mb-2">
            Truth or Dare
          </h1>
          <p className="text-gray-600">Spin the bottle, have some fun!</p>
        </div>

        <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-center text-xl">Welcome to the Game</CardTitle>
            <CardDescription className="text-center">
              Create a new room or join an existing one
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="create" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="create" className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Create
                </TabsTrigger>
                <TabsTrigger value="join" className="flex items-center gap-2">
                  <Play className="w-4 h-4" />
                  Join
                </TabsTrigger>
              </TabsList>

              <TabsContent value="create" className="space-y-4 mt-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">Your Name</label>
                  <Input
                    placeholder="Enter your name"
                    value={createPlayerName}
                    onChange={(e) => setCreatePlayerName(e.target.value)}
                    maxLength={20}
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">Room ID</label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Generate room ID"
                      value={createRoomId}
                      onChange={(e) => setCreateRoomId(e.target.value.toUpperCase())}
                      maxLength={6}
                    />
                    <Button 
                      variant="outline" 
                      onClick={generateRoomId}
                      className="px-3"
                    >
                      🎲
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    6-character room code
                  </p>
                </div>

                <Button 
                  onClick={handleCreateRoom}
                  className="w-full bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                  disabled={!createPlayerName.trim() || !createRoomId.trim()}
                >
                  Create Room
                </Button>
              </TabsContent>

              <TabsContent value="join" className="space-y-4 mt-6">
                <div>
                  <label className="text-sm font-medium mb-2 block">Your Name</label>
                  <Input
                    placeholder="Enter your name"
                    value={joinPlayerName}
                    onChange={(e) => setJoinPlayerName(e.target.value)}
                    maxLength={20}
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-2 block">Room ID</label>
                  <Input
                    placeholder="Enter room code"
                    value={roomId}
                    onChange={(e) => setRoomId(e.target.value.toUpperCase())}
                    maxLength={6}
                  />
                </div>

                <Button 
                  onClick={handleJoinRoom}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700"
                  disabled={!joinPlayerName.trim() || !roomId.trim()}
                  type="button"
                >
                  Join Room
                </Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <div className="mt-6 text-center space-y-2">
          <Badge variant="outline" className="bg-white/60">
            🎮 Multiplayer Real-time Game
          </Badge>
          <div className="flex items-center justify-center gap-2">
            <div className={`w-2 h-2 rounded-full ${
              connectionStatus === 'connected' ? 'bg-green-500' : 
              connectionStatus === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
            }`} />
            <span className="text-xs text-gray-600">
              {connectionStatus === 'connected' ? 'Connected' : 
               connectionStatus === 'connecting' ? 'Connecting...' : 'Disconnected'}
            </span>
          </div>
        </div>
      </div>
    </div>
  )
}