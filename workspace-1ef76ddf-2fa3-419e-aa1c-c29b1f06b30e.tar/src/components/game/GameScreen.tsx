'use client'

import { useState, useEffect, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog'
import { 
  RotateCw, 
  MessageCircle, 
  Send, 
  Mic, 
  ExternalLink,
  RefreshCw,
  Undo2,
  X
} from 'lucide-react'

interface Player {
  id: string
  name: string
  isHost: boolean
  position?: number
}

interface Message {
  id: string
  playerName: string
  content: string
  type: 'text' | 'emoji'
}

interface Question {
  id: string
  type: 'truth' | 'dare'
  content: string
}

interface GameScreenProps {
  roomId: string
  playerName: string
  players: Player[]
  messages: Message[]
  currentDirection: 'clockwise' | 'anticlockwise'
  currentTurn: number
  isSpinning: boolean
  selectedPlayer: Player | null
  currentQuestion: Question | null
  isHost: boolean
  onSpinBottle: () => void
  onSendMessage: (content: string) => void
  onChooseTruth: () => void
  onChooseDare: () => void
  onVoiceChat: () => void
  onCloseRoom?: () => void
}

export default function GameScreen({
  roomId,
  playerName,
  players,
  messages,
  currentDirection,
  currentTurn,
  isSpinning,
  selectedPlayer,
  currentQuestion,
  isHost,
  onSpinBottle,
  onSendMessage,
  onChooseTruth,
  onChooseDare,
  onVoiceChat,
  onCloseRoom
}: GameScreenProps) {
  const [messageInput, setMessageInput] = useState('')
  const [showChoiceDialog, setShowChoiceDialog] = useState(false)
  const bottleRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (isSpinning && bottleRef.current) {
      const spins = 5 + Math.random() * 3 // 5-8 full rotations
      const baseRotation = currentTurn * 360 // Base rotation based on turn count
      const directionMultiplier = currentDirection === 'clockwise' ? 1 : -1
      const finalRotation = baseRotation + (spins * 360 * directionMultiplier)
      
      bottleRef.current.style.transform = `rotate(${finalRotation}deg)`
      bottleRef.current.style.transition = 'transform 3s cubic-bezier(0.17, 0.67, 0.83, 0.67)'
      
      setTimeout(() => {
        setShowChoiceDialog(true)
      }, 3000)
    }
  }, [isSpinning, currentDirection, currentTurn])

  const handleSendMessage = () => {
    if (messageInput.trim()) {
      onSendMessage(messageInput.trim())
      setMessageInput('')
    }
  }

  const handleEmojiSelect = (emoji: string) => {
    onSendMessage(emoji)
  }

  const getPlayerPosition = (index: number, total: number) => {
    const angle = (360 / total) * index
    const radius = 200
    const x = Math.cos((angle - 90) * Math.PI / 180) * radius
    const y = Math.sin((angle - 90) * Math.PI / 180) * radius
    return { x, y }
  }

  const emojis = ['😂', '😱', '🔥', '💀', '👏', '😎', '🤔', '🙈']

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-blue-50 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="bg-white/60">
              Room: {roomId}
            </Badge>
            <Badge variant="outline" className="bg-white/60 flex items-center gap-1">
              {currentDirection === 'clockwise' ? (
                <RefreshCw className="w-3 h-3" />
              ) : (
                <Undo2 className="w-3 h-3" />
              )}
              {currentDirection}
            </Badge>
          </div>
          <div className="flex items-center gap-2">
            {isHost && onCloseRoom && (
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button 
                    variant="destructive"
                    size="sm"
                  >
                    <X className="w-4 h-4 mr-2" />
                    Close Room
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Close Room?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will permanently close the room and disconnect all players. This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={onCloseRoom}>Close Room</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            )}
            <Button 
              variant="outline" 
              size="sm"
              onClick={onVoiceChat}
              className="flex items-center gap-2"
            >
              <Mic className="w-4 h-4" />
              Voice Chat
              <ExternalLink className="w-3 h-3" />
            </Button>
          </div>
        </div>

        <div className="grid lg:grid-cols-4 gap-4">
          {/* Game Area */}
          <div className="lg:col-span-3">
            <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm h-[600px]">
              <CardContent className="p-6 h-full">
                <div className="relative w-full h-full flex items-center justify-center">
                  {/* Players Circle */}
                  {players.map((player, index) => {
                    const position = getPlayerPosition(index, players.length)
                    const isSelected = selectedPlayer?.id === player.id
                    return (
                      <div
                        key={player.id}
                        className={`absolute flex flex-col items-center transition-all duration-300 ${
                          isSelected ? 'scale-110 z-10' : ''
                        }`}
                        style={{
                          transform: `translate(${position.x}px, ${position.y}px)`,
                        }}
                      >
                        <Avatar className={`w-12 h-12 ${isSelected ? 'ring-4 ring-yellow-400' : ''}`}>
                          <AvatarFallback className={`${
                            isSelected 
                              ? 'bg-yellow-400 text-white' 
                              : 'bg-gradient-to-br from-pink-400 to-purple-600 text-white'
                          }`}>
                            {player.name.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-xs mt-1 font-medium">
                          {player.name}
                          {player.name === playerName && " (You)"}
                        </span>
                        {isSelected && (
                          <Badge className="mt-1 bg-yellow-400 text-yellow-900">
                            Selected!
                          </Badge>
                        )}
                      </div>
                    )
                  })}

                  {/* Bottle */}
                  <div 
                    ref={bottleRef}
                    className="absolute w-20 h-32 cursor-pointer"
                    onClick={() => !isSpinning && onSpinBottle()}
                  >
                    <img 
                      src="/bottle.png" 
                      alt="Spinning Bottle"
                      className="w-full h-full object-contain drop-shadow-lg"
                    />
                  </div>

                  {/* Spin Button */}
                  {!isSpinning && !selectedPlayer && (
                    <Button 
                      onClick={onSpinBottle}
                      className="absolute bottom-8 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700"
                      size="lg"
                    >
                      <RotateCw className="w-5 h-5 mr-2" />
                      Spin the Bottle!
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chat Area */}
          <div className="lg:col-span-1">
            <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm h-[600px] flex flex-col">
              <CardContent className="p-4 flex-1 flex flex-col">
                <div className="flex items-center gap-2 mb-3">
                  <MessageCircle className="w-5 h-5" />
                  <h3 className="font-semibold">Chat</h3>
                </div>

                {/* Messages */}
                <div className="flex-1 mb-3 overflow-y-auto max-h-60">
                  <div className="space-y-2">
                    {messages.map((message, index) => (
                      <div key={`${message.id}-${index}`} className="text-sm">
                        <span className="font-medium text-purple-600">
                          {message.playerName}:
                        </span>
                        <span className="ml-1">
                          {message.content}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Emoji Picker */}
                <div className="flex gap-1 mb-3">
                  {emojis.map((emoji) => (
                    <Button
                      key={emoji}
                      variant="outline"
                      size="sm"
                      onClick={() => handleEmojiSelect(emoji)}
                      className="text-lg p-2 h-8 w-8"
                    >
                      {emoji}
                    </Button>
                  ))}
                </div>

                {/* Message Input */}
                <div className="flex gap-2">
                  <Input
                    placeholder="Type a message..."
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
                  <Button 
                    size="sm" 
                    onClick={handleSendMessage}
                    className="bg-purple-500 hover:bg-purple-600"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Truth or Dare Choice Dialog */}
      <Dialog open={showChoiceDialog && selectedPlayer?.name === playerName} onOpenChange={setShowChoiceDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-center text-xl">
              {selectedPlayer?.name}, it's your turn!
            </DialogTitle>
            <DialogDescription className="text-center">
              Choose your destiny: Truth or Dare?
            </DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4 mt-6">
            <Button 
              onClick={() => {
                onChooseTruth()
                setShowChoiceDialog(false)
              }}
              className="bg-pink-500 hover:bg-pink-600 h-16 text-lg"
            >
              Truth
            </Button>
            <Button 
              onClick={() => {
                onChooseDare()
                setShowChoiceDialog(false)
              }}
              className="bg-blue-500 hover:bg-blue-600 h-16 text-lg"
            >
              Dare
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Question Display Dialog */}
      <Dialog open={!!currentQuestion && selectedPlayer?.name === playerName}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="text-center text-xl">
              {currentQuestion?.type === 'truth' ? '🤔 Truth' : '🎯 Dare'}
            </DialogTitle>
          </DialogHeader>
          <div className="text-center py-6">
            <p className="text-lg font-medium">
              {currentQuestion?.content}
            </p>
          </div>
          <Button 
            onClick={() => setShowChoiceDialog(false)}
            className="w-full"
          >
            Got it!
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  )
}