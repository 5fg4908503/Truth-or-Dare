'use client'

import { useState, useEffect, useRef } from 'react'
import { io, Socket } from 'socket.io-client'
import Lobby from './Lobby'
import WaitingRoom from './WaitingRoom'
import GameScreen from './GameScreen'

interface Player {
  id: string
  name: string
  isHost: boolean
  isReady: boolean
}

interface Question {
  id: string
  type: 'truth' | 'dare'
  content: string
  playerId: string
}

interface Message {
  id: string
  playerName: string
  content: string
  type: 'text' | 'emoji'
}

type GameState = 'lobby' | 'waiting' | 'playing'

export default function TruthOrDareGame() {
  const [gameState, setGameState] = useState<GameState>('lobby')
  const [socket, setSocket] = useState<Socket | null>(null)
  const [roomId, setRoomId] = useState('')
  const [playerName, setPlayerName] = useState('')
  const [isHost, setIsHost] = useState(false)
  const [players, setPlayers] = useState<Player[]>([])
  const [questions, setQuestions] = useState<Question[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [currentDirection, setCurrentDirection] = useState<'clockwise' | 'anticlockwise'>('clockwise')
  const [currentTurn, setCurrentTurn] = useState(0)
  const [isSpinning, setIsSpinning] = useState(false)
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null)
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null)
  const [connectionStatus, setConnectionStatus] = useState<'connecting' | 'connected' | 'disconnected'>('connecting')

  useEffect(() => {
    const socketInstance = io('/', {
      path: '/api/socketio',
      transports: ['polling', 'websocket'],
    })
    setSocket(socketInstance)

    // Connection events
    socketInstance.on('connect', () => {
      console.log('Connected to server with socket ID:', socketInstance.id)
      setConnectionStatus('connected')
    })

    socketInstance.on('disconnect', () => {
      console.log('Disconnected from server')
      setConnectionStatus('disconnected')
    })

    socketInstance.on('connect_error', (error) => {
      console.error('Connection error:', error)
      setConnectionStatus('disconnected')
    })

    socketInstance.on('roomCreated', (data: { roomId: string; player: Player }) => {
      setRoomId(data.roomId)
      setPlayerName(data.player.name)
      setIsHost(true)
      setPlayers([data.player])
      setGameState('waiting')
    })

    socketInstance.on('roomJoined', (data: { roomId: string; player: Player; room?: any }) => {
      setRoomId(data.roomId)
      setPlayerName(data.player.name)
      setIsHost(data.player.isHost)
      setGameState('waiting')
      
      // Load room data if provided
      if (data.room) {
        setPlayers(data.room.players || [])
        setQuestions(data.room.questions || [])
        setMessages(data.room.messages || [])
        setCurrentDirection(data.room.direction || 'clockwise')
        setCurrentTurn(data.room.currentTurn || 0)
      }
    })

    socketInstance.on('playerJoined', (data: { player: Player; players: Player[] }) => {
      setPlayers(data.players)
    })

    socketInstance.on('playerLeft', (data: { player: Player; players: Player[] }) => {
      setPlayers(data.players)
    })

    socketInstance.on('questionAdded', (data: { question: Question; questions: Question[] }) => {
      setQuestions(data.questions)
    })

    socketInstance.on('playerReady', (data: { player: Player; players: Player[] }) => {
      setPlayers(data.players)
    })

    socketInstance.on('gameStarted', (data: { room: any }) => {
      setGameState('playing')
      setCurrentDirection(data.room.direction)
    })

    socketInstance.on('bottleSpun', (data: { selectedPlayer: Player; direction: string; currentTurn: number }) => {
      setSelectedPlayer(data.selectedPlayer)
      setCurrentDirection(data.direction as 'clockwise' | 'anticlockwise')
      setCurrentTurn(data.currentTurn)
      setIsSpinning(true)
      
      setTimeout(() => {
        setIsSpinning(false)
      }, 3000)
    })

    socketInstance.on('questionSelected', (data: { question: Question }) => {
      setCurrentQuestion(data.question)
    })

    socketInstance.on('newMessage', (message: Message) => {
      setMessages(prev => [...prev, message])
    })

    socketInstance.on('error', (data: { message: string }) => {
      console.error('Socket error:', data.message)
    })

    socketInstance.on('roomClosed', () => {
      console.log('Room closed, returning to lobby')
      setGameState('lobby')
      setRoomId('')
      setPlayerName('')
      setIsHost(false)
      setPlayers([])
      setQuestions([])
      setMessages([])
      setCurrentDirection('clockwise')
      setCurrentTurn(0)
      setIsSpinning(false)
      setSelectedPlayer(null)
      setCurrentQuestion(null)
    })

    return () => {
      socketInstance.disconnect()
    }
  }, [])

  const handleCreateRoom = (name: string, roomCode: string) => {
    if (socket) {
      socket.emit('createRoom', { playerName: name, roomId: roomCode })
    }
  }

  const handleJoinRoom = (name: string, roomCode: string) => {
    if (socket) {
      socket.emit('joinRoom', { playerName: name, roomId: roomCode })
    }
  }

  const handleAddQuestion = (type: 'truth' | 'dare', content: string) => {
    if (socket) {
      socket.emit('addQuestion', { type, content })
    }
  }

  const handleReady = () => {
    if (socket) {
      socket.emit('playerReady')
    }
  }

  const handleStartGame = () => {
    if (socket) {
      socket.emit('startGame')
    }
  }

  const handleSpinBottle = () => {
    if (socket && !isSpinning) {
      socket.emit('spinBottle')
    }
  }

  const handleSendMessage = (content: string) => {
    if (socket) {
      socket.emit('sendMessage', { content })
    }
  }

  const handleChooseTruth = () => {
    if (socket) {
      socket.emit('chooseTruth')
    }
  }

  const handleChooseDare = () => {
    if (socket) {
      socket.emit('chooseDare')
    }
  }

  const handleVoiceChat = () => {
    // Open Discord or other voice chat
    window.open('https://discord.com', '_blank')
  }

  const handleCloseRoom = () => {
    if (socket) {
      socket.emit('closeRoom')
    }
  }

  if (gameState === 'lobby') {
    return (
      <Lobby 
        onCreateRoom={handleCreateRoom}
        onJoinRoom={handleJoinRoom}
        connectionStatus={connectionStatus}
      />
    )
  }

  if (gameState === 'waiting') {
    return (
      <WaitingRoom
        roomId={roomId}
        playerName={playerName}
        isHost={isHost}
        players={players}
        questions={questions}
        onStartGame={handleStartGame}
        onAddQuestion={handleAddQuestion}
        onReady={handleReady}
        onCloseRoom={handleCloseRoom}
      />
    )
  }

  if (gameState === 'playing') {
    return (
      <GameScreen
        roomId={roomId}
        playerName={playerName}
        players={players}
        messages={messages}
        currentDirection={currentDirection}
        currentTurn={currentTurn}
        isSpinning={isSpinning}
        selectedPlayer={selectedPlayer}
        currentQuestion={currentQuestion}
        isHost={isHost}
        onSpinBottle={handleSpinBottle}
        onSendMessage={handleSendMessage}
        onChooseTruth={handleChooseTruth}
        onChooseDare={handleChooseDare}
        onVoiceChat={handleVoiceChat}
        onCloseRoom={handleCloseRoom}
      />
    )
  }

  return null
}