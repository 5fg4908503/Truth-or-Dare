'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog'
import { Users, Play, Plus, MessageCircle, Sparkles, X, LogOut } from 'lucide-react'

interface Player {
  id: string
  name: string
  isHost: boolean
  isReady: boolean
}

interface Question {
  id: string
  type: 'truth' | 'dare'
  content: string
  playerId: string
}

interface WaitingRoomProps {
  roomId: string
  playerName: string
  isHost: boolean
  players: Player[]
  questions: Question[]
  onStartGame: () => void
  onAddQuestion: (type: 'truth' | 'dare', content: string) => void
  onReady: () => void
  onCloseRoom?: () => void
}

export default function WaitingRoom({
  roomId,
  playerName,
  isHost,
  players,
  questions,
  onStartGame,
  onAddQuestion,
  onReady,
  onCloseRoom
}: WaitingRoomProps) {
  const [newTruth, setNewTruth] = useState('')
  const [newDare, setNewDare] = useState('')
  const [isReady, setIsReady] = useState(false)

  const handleAddTruth = () => {
    if (newTruth.trim()) {
      onAddQuestion('truth', newTruth.trim())
      setNewTruth('')
    }
  }

  const handleAddDare = () => {
    if (newDare.trim()) {
      onAddQuestion('dare', newDare.trim())
      setNewDare('')
    }
  }

  const handleReady = () => {
    setIsReady(true)
    onReady()
  }

  const allPlayersReady = players.length > 0 && players.every(p => p.isReady)
  const hasQuestions = questions.length > 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 mb-2">
            <Sparkles className="w-6 h-6 text-purple-600" />
            <h1 className="text-3xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
              Truth or Dare
            </h1>
          </div>
          <Badge variant="outline" className="bg-white/60">
            Room: {roomId}
          </Badge>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Players Section */}
          <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="w-5 h-5" />
                Players ({players.length})
              </CardTitle>
              <CardDescription>
                {isHost ? "You're the host" : "Waiting for host to start"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                <div className="space-y-3">
                  {players.map((player) => (
                    <div key={player.id} className="flex items-center justify-between p-2 rounded-lg bg-gray-50">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-8 h-8">
                          <AvatarFallback className="bg-gradient-to-br from-pink-400 to-purple-600 text-white text-sm">
                            {player.name.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-sm">
                            {player.name}
                            {player.name === playerName && " (You)"}
                          </p>
                          {player.isHost && (
                            <Badge variant="secondary" className="text-xs">
                              Host
                            </Badge>
                          )}
                        </div>
                      </div>
                      <Badge 
                        variant={player.isReady ? "default" : "outline"}
                        className={player.isReady ? "bg-green-500" : ""}
                      >
                        {player.isReady ? "Ready" : "Waiting"}
                      </Badge>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              {!isReady && (
                <Button 
                  onClick={handleReady}
                  className="w-full mt-4"
                  disabled={isReady}
                >
                  {isReady ? "Ready!" : "I'm Ready"}
                </Button>
              )}

              {isHost && allPlayersReady && hasQuestions && (
                <>
                  <Button 
                    onClick={onStartGame}
                    className="w-full mt-2 bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700"
                  >
                    <Play className="w-4 h-4 mr-2" />
                    Start Game
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button 
                        variant="destructive"
                        className="w-full mt-2"
                      >
                        <X className="w-4 h-4 mr-2" />
                        Close Room
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Close Room?</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will permanently close the room and disconnect all players. This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={onCloseRoom}>Close Room</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </>
              )}

              {isHost && (!allPlayersReady || !hasQuestions) && (
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button 
                      variant="outline"
                      className="w-full mt-2"
                    >
                      <X className="w-4 h-4 mr-2" />
                      Close Room
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Close Room?</AlertDialogTitle>
                      <AlertDialogDescription>
                        This will permanently close the room and disconnect all players. This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={onCloseRoom}>Close Room</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              )}
            </CardContent>
          </Card>

          {/* Questions Section */}
          <Card className="shadow-lg border-0 bg-white/80 backdrop-blur-sm lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5" />
                Add Questions
              </CardTitle>
              <CardDescription>
                Add some truth and dare questions to get started!
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-4">
                {/* Truth Questions */}
                <div>
                  <h3 className="font-medium mb-3 text-pink-600">Truth Questions</h3>
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add a truth question..."
                        value={newTruth}
                        onChange={(e) => setNewTruth(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleAddTruth()}
                      />
                      <Button 
                        size="sm" 
                        onClick={handleAddTruth}
                        className="bg-pink-500 hover:bg-pink-600"
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                    <ScrollArea className="h-48">
                      <div className="space-y-2">
                        {questions
                          .filter(q => q.type === 'truth')
                          .map((question) => (
                            <div key={question.id} className="p-2 rounded-lg bg-pink-50 text-sm">
                              {question.content}
                            </div>
                          ))}
                      </div>
                    </ScrollArea>
                  </div>
                </div>

                {/* Dare Questions */}
                <div>
                  <h3 className="font-medium mb-3 text-blue-600">Dare Questions</h3>
                  <div className="space-y-2">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add a dare question..."
                        value={newDare}
                        onChange={(e) => setNewDare(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleAddDare()}
                      />
                      <Button 
                        size="sm" 
                        onClick={handleAddDare}
                        className="bg-blue-500 hover:bg-blue-600"
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                    <ScrollArea className="h-48">
                      <div className="space-y-2">
                        {questions
                          .filter(q => q.type === 'dare')
                          .map((question) => (
                            <div key={question.id} className="p-2 rounded-lg bg-blue-50 text-sm">
                              {question.content}
                            </div>
                          ))}
                      </div>
                    </ScrollArea>
                  </div>
                </div>
              </div>

              <Separator className="my-4" />
              
              <div className="text-center text-sm text-gray-600">
                Total Questions: {questions.length} 
                {questions.filter(q => q.type === 'truth').length > 0 && (
                  <span className="ml-2 text-pink-600">
                    ({questions.filter(q => q.type === 'truth').length} truths)
                  </span>
                )}
                {questions.filter(q => q.type === 'dare').length > 0 && (
                  <span className="ml-1 text-blue-600">
                    ({questions.filter(q => q.type === 'dare').length} dares)
                  </span>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}