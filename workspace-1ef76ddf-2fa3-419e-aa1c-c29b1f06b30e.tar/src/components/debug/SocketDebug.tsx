'use client'

import { useState, useEffect } from 'react'
import { io, Socket } from 'socket.io-client'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function SocketDebug() {
  const [socket, setSocket] = useState<Socket | null>(null)
  const [logs, setLogs] = useState<string[]>([])
  const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connecting' | 'connected'>('disconnected')

  const addLog = (message: string) => {
    setLogs(prev => [...prev, `${new Date().toLocaleTimeString()}: ${message}`])
  }

  const connect = () => {
    addLog('Attempting to connect...')
    setConnectionStatus('connecting')
    
    const socketInstance = io({
      path: '/api/socketio',
      transports: ['websocket', 'polling']
    })

    socketInstance.on('connect', () => {
      addLog(`Connected with socket ID: ${socketInstance.id}`)
      setConnectionStatus('connected')
    })

    socketInstance.on('disconnect', () => {
      addLog('Disconnected from server')
      setConnectionStatus('disconnected')
    })

    socketInstance.on('connect_error', (error) => {
      addLog(`Connection error: ${error.message}`)
      setConnectionStatus('disconnected')
    })

    setSocket(socketInstance)
  }

  const disconnect = () => {
    if (socket) {
      socket.disconnect()
      setSocket(null)
      setConnectionStatus('disconnected')
      addLog('Manually disconnected')
    }
  }

  const testCreateRoom = () => {
    if (socket) {
      addLog('Sending createRoom event...')
      socket.emit('createRoom', { playerName: 'TestPlayer', roomId: 'TEST123' })
    }
  }

  const clearLogs = () => {
    setLogs([])
  }

  useEffect(() => {
    return () => {
      if (socket) {
        socket.disconnect()
      }
    }
  }, [socket])

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Socket.io Debug</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${
              connectionStatus === 'connected' ? 'bg-green-500' : 
              connectionStatus === 'connecting' ? 'bg-yellow-500' : 'bg-red-500'
            }`} />
            <span className="font-medium">
              Status: {connectionStatus}
            </span>
          </div>

          <div className="flex gap-2">
            <Button onClick={connect} disabled={connectionStatus !== 'disconnected'}>
              Connect
            </Button>
            <Button onClick={disconnect} disabled={connectionStatus === 'disconnected'}>
              Disconnect
            </Button>
            <Button onClick={testCreateRoom} disabled={connectionStatus !== 'connected'}>
              Test Create Room
            </Button>
            <Button onClick={clearLogs} variant="outline">
              Clear Logs
            </Button>
          </div>

          <div className="bg-gray-100 p-3 rounded-lg h-64 overflow-y-auto">
            <h3 className="font-semibold mb-2">Logs:</h3>
            {logs.length === 0 ? (
              <p className="text-gray-500">No logs yet...</p>
            ) : (
              logs.map((log, index) => (
                <div key={index} className="text-sm font-mono">
                  {log}
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}